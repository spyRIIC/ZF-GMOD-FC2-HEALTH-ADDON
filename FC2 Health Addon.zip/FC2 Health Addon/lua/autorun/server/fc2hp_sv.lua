local NoHolsterAnimVModels = {
"models/weapons/v_c4.mdl",
"models/weapons/v_eq_flashbang.mdl",
"models/weapons/v_eq_fraggrenade.mdl",
"models/weapons/v_smokegrenade.mdl",
"models/weapons/v_knife_t.mdl",
"models/weapons/v_mach_m249para.mdl",
"models/weapons/v_pist_deagle.mdl",
"models/weapons/v_pist_elite.mdl",
"models/weapons/v_pist_fiveseven.mdl",
"models/weapons/v_pist_glock18.mdl",
"models/weapons/v_pist_p228.mdl",
"models/weapons/v_pist_usp.mdl",
"models/weapons/v_rif_ak47.mdl",
"models/weapons/v_rif_aug.mdl",
"models/weapons/v_rif_famas.mdl",
"models/weapons/v_rif_galil.mdl",
"models/weapons/v_rif_m4a1.mdl",
"models/weapons/v_rif_sg552.mdl",
"models/weapons/v_shot_m2super90.mdl",
"models/weapons/v_shot_xm1014.mdl",
"models/weapons/v_smg_mac10.mdl",
"models/weapons/v_smg_mp5.mdl",
"models/weapons/v_smg_p90.mdl",
"models/weapons/v_smg_tmp.mdl",
"models/weapons/v_smg_ump45.mdl",
"models/weapons/v_snip_awp.mdl",
"models/weapons/v_snip_g3sg1.mdl",
"models/weapons/v_snip_scout.mdl",
"models/weapons/v_snip_sg550.mdl"}

-- What are you doing in here?! :o your not supposed to be in heeeeeeeeereeeeeeee get out now you sharliton! mmmmyesss

function LowHPStat(ply)
umsg.Start("FCHasLowHP",ply)
umsg.Bool(ply.HasLowHP)
umsg.End()
end

function FCHPSpawn(ply)
ply.HPFC = 1
ply.FC2Regen = CurTime()
ply.HasLowHP = false
ply.Syrettes = 4
ply.MaxSyrettes = 6
ply.HasExtendedKit = false
LowHPStat(ply)
if ply.LowHealthFC then
ply.LowHealthFC:Stop()
end
ply.LowHealthFC = CreateSound( ply, "player/heartbeat1.wav" )
umsg.Start("FCSpawnGiveSyrettes",ply)
umsg.Float(ply.Syrettes)
umsg.End()
timer.Simple(2,function()
if not ValidEntity(ply) or not ply:Alive() then return false end
ply:Give("fc2_syrette")
ply:Give("fc2_syrette_idle")
end)
end
hook.Add("PlayerSpawn","FCHPSpawnHK",FCHPSpawn)

function FCHPLeave(ply)
if ply.LowHealthFC then
ply.LowHealthFC:Stop()
end
end
hook.Add("PlayerDisconnected","FCHPLeaveHK",FCHPLeave)

timer.Create("CheckIfIdle",1,0,function()
for k,v in pairs (player.GetAll()) do
if not v:KeyDown(IN_FORWARD) and not v:KeyDown(IN_MOVELEFT) and not v:KeyDown(IN_MOVERIGHT) and not v:KeyDown(IN_BACK) and not v.IsIdle then
v.IsIdle = true
v.SyretteIdle = CurTime() + 20
elseif (v:KeyDown(IN_FORWARD) or v:KeyDown(IN_MOVELEFT) or v:KeyDown(IN_MOVERIGHT) or v:KeyDown(IN_BACK)) and v.IsIdle then
v.IsIdle = false
v.SyretteIdle = nil
end
end
end)

timer.Create("NaturalHealSets",0.25,0,function()
for k,v in pairs (player.GetAll()) do
if v:Health() > v:GetMaxHealth()*0 then
v.HPFC = 0.2
if not v.HasLowHP and v:Health() <= v:GetMaxHealth()*0.2 then
v:SetHealth(v:GetMaxHealth()*0.2)
v.HasLowHP = true
LowHPStat(v)
v.LowHealthFC:Play()
v.FC2Regen = CurTime() + 1
end
end
if v:Health() > v:GetMaxHealth()*0.2 then
v.HPFC = 0.4
if v.HasLowHP then
v.HasLowHP = false
LowHPStat(v)
v.LowHealthFC:FadeOut(2)
end
end
if v:Health() > v:GetMaxHealth()*0.4 then
v.HPFC = 0.6
if v.HasLowHP then
v.HasLowHP = false
LowHPStat(v)
v.LowHealthFC:FadeOut(2)
end
end
if v:Health() > v:GetMaxHealth()*0.6 then
v.HPFC = 0.8
if v.HasLowHP then
v.HasLowHP = false
LowHPStat(v)
v.LowHealthFC:FadeOut(2)
end
end
if v:Health() > v:GetMaxHealth()*0.8 then
v.HPFC = 1
if v.HasLowHP then
v.HasLowHP = false
LowHPStat(v)
v.LowHealthFC:FadeOut(2)
end
end
end
end)

function FCPlayerDM(ent, attacker, hpl, amount)
ent.FC2Regen = CurTime() + 7
if hpl <= ent:GetMaxHealth() then
ent.HPFC = 1
end
if hpl <= ent:GetMaxHealth()*0.8 then
ent.HPFC = 0.8
end
if hpl <= ent:GetMaxHealth()*0.6 then
ent.HPFC = 0.6
end
if hpl <= ent:GetMaxHealth()*0.4 then
ent.HPFC = 0.4
end
if hpl <= ent:GetMaxHealth()*0.2 then
if not ent.HasLowHP and amount < ent:GetMaxHealth()*0.2 then
ent:SetHealth(ent:GetMaxHealth()*0.2)
ent.HasLowHP = true
LowHPStat(ent)
ent.LowHealthFC:Play()
end
ent.FC2Regen = CurTime() + 1
ent.HPFC = 0.2
end
end
hook.Add("PlayerHurt","FCPlayerDMHK",FCPlayerDM)

function FCHPPressedKey(ply, key)
if key == IN_ATTACK or key == IN_ATTACK2 or key == IN_RELOAD then
ply.SyretteIdle = nil
ply.IsIdle = false
end
end
hook.Add("KeyPress","FCHPPressedKeyHK",FCHPPressedKey)

function FCHPThink()
for k,v in pairs (player.GetAll()) do
if v.DoSyretteIdle and CurTime() >= v.DoSyretteIdle then
v.DoSyretteIdle = nil
if v:HasWeapon("fc2_syrette_idle") then
v:SelectWeapon("fc2_syrette_idle")
end
end
if not v.StartSyrette and v.SyretteIdle and CurTime() >= v.SyretteIdle then
v.SyretteIdle = nil
if v:GetActiveWeapon():IsValid() then
if table.HasValue(NoHolsterAnimVModels, v:GetViewModel():GetModel()) then
v.DoSyretteIdle = CurTime()
else
v:GetActiveWeapon().Idle = nil
v:GetActiveWeapon():SendWeaponAnim(ACT_VM_HOLSTER)
v.DoSyretteIdle = CurTime() + v:GetViewModel():SequenceDuration()
end
else
v.DoSyretteIdle = CurTime() + v:GetViewModel():SequenceDuration()
end
end
if v.StartSyrette and CurTime() >= v.StartSyrette then
v.StartSyrette = nil
v:SelectWeapon("fc2_syrette")
end
if v.FC2Regen and CurTime() >= v.FC2Regen then
if (v.HPFC == 0.2) then
if v:GetActiveWeapon():IsValid() and v:GetActiveWeapon():GetClass() == "fc2_syrette" then return end
v.FC2Regen = CurTime() + 2
v:SetHealth(v:Health() - 2)
if v:Health() <= 0 and v:Alive() then v:Kill() end
return end
if (v:Health() < v:GetMaxHealth()*v.HPFC) and not v.Poisoned and not v.Incapped then
v.FC2Regen = CurTime() + 0.04
v:SetHealth(v:Health() + 1)
if (v:Health() > v:GetMaxHealth()*v.HPFC) then v:SetHealth(v:GetMaxHealth()*v.HPFC) end
end
end
end
end
hook.Add("Think","FCHPThinkHK",FCHPThink)

function FCHeal(ply,com,arg)
if ply:HasWeapon("fc2_syrette") and ply.Syrettes >= 1 and ply:Health() < ply:GetMaxHealth() and ply:Alive() then
if ply:GetActiveWeapon():IsValid() then
if table.HasValue(NoHolsterAnimVModels, ply:GetViewModel():GetModel()) then
ply.StartSyrette = CurTime()
else
ply:GetActiveWeapon().Idle = nil
ply:GetActiveWeapon():SendWeaponAnim(ACT_VM_HOLSTER)
ply.StartSyrette = CurTime() + ply:GetViewModel():SequenceDuration()
end
else
ply.StartSyrette = CurTime() + ply:GetViewModel():SequenceDuration()
end
end
end
concommand.Add("fcheal",FCHeal)