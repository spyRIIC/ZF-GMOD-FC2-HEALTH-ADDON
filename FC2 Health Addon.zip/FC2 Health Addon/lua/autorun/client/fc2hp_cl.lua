local function FCUsedSyrette( um )
LocalPlayer().SyretteGiven = false
LocalPlayer().BlurBuildupSYR = true
LocalPlayer().Syrettes = LocalPlayer().Syrettes - 1
LocalPlayer().SyretteAlpha = 255
LocalPlayer().SyretteRemoval = true
end
usermessage.Hook( "FCUsedSyrette", FCUsedSyrette )

local function FCGiveSyrettes( um )
LocalPlayer().SyretteRemoval = false
LocalPlayer().SyretteAlpha = 0
LocalPlayer().SyretteGiven = true
LocalPlayer().FakeSyrettes = LocalPlayer().Syrettes
LocalPlayer().Syrettes = um:ReadFloat()
end
usermessage.Hook( "FCGiveSyrettes", FCGiveSyrettes )

local function FCSpawnGiveSyrettes( um )
LocalPlayer().SyretteRemoval = false
LocalPlayer().SyretteAlpha = 0
LocalPlayer().SyretteGiven = true
LocalPlayer().FakeSyrettes = 0
LocalPlayer().Syrettes = um:ReadFloat()
end
usermessage.Hook( "FCSpawnGiveSyrettes", FCSpawnGiveSyrettes )

local function FCHasLowHP( um )
LocalPlayer().HasLowHP = um:ReadBool()
LocalPlayer().FCRed = 0
LocalPlayer().FCRedDIR = true
end
usermessage.Hook( "FCHasLowHP", FCHasLowHP )

CreateClientConVar( "FC_Syrettes_X", 0, true, false )
CreateClientConVar( "FC_Syrettes_Y", 0, true, false )

local SYRTexture = surface.GetTextureID( "HUD/syrmatz" );
 
function SyrettePaint() -- I know this is a mess but hey, It works, Now get out... :o
local Yourself = LocalPlayer()
if not Yourself.Syrettes then Yourself.Syrettes = 4 end
if not Yourself.FakeSyrettes then
LocalPlayer().SyretteRemoval = false
LocalPlayer().SyretteAlpha = 0
LocalPlayer().SyretteGiven = true
LocalPlayer().FakeSyrettes = 0
end
	local SYRSize = ScreenScale(23)
	local Offset = SYRSize / 2
	local Height = 1.16 + GetConVarNumber("FC_Syrettes_Y")*0.005
	
	surface.SetTexture( SYRTexture )
	if Yourself.SyretteGiven == true then
	surface.SetDrawColor( 255, 255, 255, 255 )
	
	if Yourself.FakeSyrettes == 0 then
		if Yourself.Syrettes == 1 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 2 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 3 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 4 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 5 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 6 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 1 then
		if Yourself.Syrettes == 2 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 3 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 4 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 5 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 6 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 2 then
	if Yourself.Syrettes == 3 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 4 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 5 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 6 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 3 then
	if Yourself.Syrettes == 4 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 5 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 6 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 4 then
	if Yourself.Syrettes == 5 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 6 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 5 then
	if Yourself.Syrettes == 6 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 6 then
		if Yourself.Syrettes == 7 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.FakeSyrettes == 7 then
		if Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.SetDrawColor( 0 + Yourself.SyretteAlpha, 255, 255, Yourself.SyretteAlpha )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		end
		if Yourself.SyretteAlpha < 255 then
		Yourself.SyretteAlpha = Yourself.SyretteAlpha + RealFrameTime()*175
		if Yourself.SyretteAlpha >= 255 then
		Yourself.FakeSyrettes = Yourself.Syrettes
		Yourself.SyretteGiven = false
		end
		end
	elseif Yourself.Syrettes == 8 then
		surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
		Yourself.SyretteGiven = false
	end
	return end
	
	if Yourself.SyretteRemoval == true then
	surface.SetDrawColor( 255, 255, 255, 255 )
	if Yourself.FakeSyrettes == 1 then
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 2 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 3 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 4 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 5 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 6 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 7 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	elseif Yourself.FakeSyrettes == 8 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.SetDrawColor( 255, 0 + Yourself.SyretteAlpha, 0 + Yourself.SyretteAlpha, Yourself.SyretteAlpha )
	surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	if Yourself.SyretteAlpha > 0 then
	Yourself.SyretteAlpha = Yourself.SyretteAlpha - RealFrameTime()*175
	if Yourself.SyretteAlpha <= 0 then
	Yourself.FakeSyrettes = Yourself.Syrettes
	Yourself.SyretteRemoval = false
	end
	end
	end
	return end
 
	surface.SetDrawColor( 255, 255, 255, 255 )
	if Yourself.Syrettes == 1 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 2 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 3 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 4 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 5 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 6 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 7 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	elseif Yourself.Syrettes == 8 then
	surface.DrawTexturedRect( ( ScrW() * 0.03 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.05 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.07 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.09 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.11 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.13 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.15 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	surface.DrawTexturedRect( ( ScrW() * 0.17 ) - Offset + GetConVarNumber("FC_Syrettes_X"), ( ScrH() / Height ) - Offset, SYRSize, SYRSize )
	end
end
hook.Add( "HUDPaint", "SyrettePaint", SyrettePaint )

local function FCSyretteBlurValues( x, y, fwd, spin )
if not LocalPlayer().BlurAmountSYR then LocalPlayer().BlurAmountSYR = 0 end
if LocalPlayer().BlurBuildupSYR == true then
if LocalPlayer().BlurAmountSYR < 0.075 then
LocalPlayer().BlurAmountSYR = LocalPlayer().BlurAmountSYR + RealFrameTime()*0.05
if LocalPlayer().BlurAmountSYR > 0.075 then LocalPlayer().BlurAmountSYR = 0.075;LocalPlayer().BlurBuildupSYR = false end
return 0, 0, LocalPlayer().BlurAmountSYR, 0
end
return end
if LocalPlayer().BlurAmountSYR then
	if LocalPlayer().BlurAmountSYR > 0 then
	LocalPlayer().BlurAmountSYR = LocalPlayer().BlurAmountSYR - RealFrameTime()*0.05
	end
	if LocalPlayer().BlurAmountSYR > 0 then
	return 0, 0, LocalPlayer().BlurAmountSYR, 0
	end
end
end
hook.Add( "GetMotionBlurValues", "SYRFCBlurValues", FCSyretteBlurValues )

local function FCLowHealthEff()
local Yourself = LocalPlayer()
if not Yourself.FCRed then Yourself.FCRed = 0 end
if Yourself.HasLowHP then
if Yourself.FCRedDIR == true and Yourself.FCRed < 0.2 then
Yourself.FCRed = Yourself.FCRed + RealFrameTime()*0.5
if Yourself.FCRed >= 0.2 then Yourself.FCRed = 0.2;Yourself.FCRedDIR = false end
elseif Yourself.FCRedDIR == false and Yourself.FCRed > 0 then
Yourself.FCRed = Yourself.FCRed - RealFrameTime()*0.5
if Yourself.FCRed <= 0 then Yourself.FCRed = 0;Yourself.FCRedDIR = true end
end
else
if Yourself.FCRed > 0 then Yourself.FCRed = Yourself.FCRed - RealFrameTime()*0.5;Yourself.FCRedDIR = true;if Yourself.FCRed < 0 then Yourself.FCRed = 0 end end
end
if Yourself.FCRed > 0 then
local FCRedLowHP = {}
FCRedLowHP[ "$pp_colour_addr" ] = Yourself.FCRed
FCRedLowHP[ "$pp_colour_addg" ] = 0
FCRedLowHP[ "$pp_colour_addb" ] = 0
FCRedLowHP[ "$pp_colour_brightness" ] = 0
FCRedLowHP[ "$pp_colour_contrast" ] = 1
FCRedLowHP[ "$pp_colour_colour" ] = 1
FCRedLowHP[ "$pp_colour_mulr" ] = 0
FCRedLowHP[ "$pp_colour_mulg" ] = 0
FCRedLowHP[ "$pp_colour_mulb" ] = 0 
DrawColorModify( FCRedLowHP )
end
end
hook.Add("RenderScreenspaceEffects","FCLowHealthEff",FCLowHealthEff)