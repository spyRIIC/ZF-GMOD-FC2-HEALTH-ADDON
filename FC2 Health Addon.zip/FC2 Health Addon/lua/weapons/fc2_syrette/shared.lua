AddCSLuaFile("shared.lua")

SWEP.HoldType		= "slam"

if (CLIENT) then
	SWEP.DrawCrosshair		= false
	SWEP.Crosshair			= false
	SWEP.DrawAmmo			= false
	SWEP.Category 			= "FC2"
	SWEP.PrintName			= "Syrette"	
	SWEP.Slot 				= 99
	SWEP.SlotPos 			= 99
	SWEP.IconLetter 		= "F"
	SWEP.IconLetterSelect	= "F"
	SWEP.ViewModelFOV		= 65

	killicon.AddFont("fc2_syrette", "CSKillIcons", SWEP.IconLetter, Color( 0, 200, 0, 255 ) )
end

function SWEP:DrawWeaponSelection(x, y, wide, tall, alpha)

	draw.SimpleText(self.IconLetterSelect, "CSKillIcons", x + wide / 2, y + tall * 0.2, Color(255, 210, 0, 255), TEXT_ALIGN_CENTER)

	self:PrintWeaponInfo(x + wide + 20, y + tall * 0.95, alpha)
end

function SWEP:DrawWorldModel()

local hand, offset, rotate

if not ValidEntity(self.Owner) then
self:DrawModel()
return
end

hand = self.Owner:GetAttachment(self.Owner:LookupAttachment("anim_attachment_rh"))

offset = hand.Ang:Right() * -0.8 - hand.Ang:Forward() * 0 + hand.Ang:Up() * 0

hand.Ang:RotateAroundAxis(hand.Ang:Right(), -10)
hand.Ang:RotateAroundAxis(hand.Ang:Forward(), 90)
hand.Ang:RotateAroundAxis(hand.Ang:Up(), 0)

self:SetRenderOrigin(hand.Pos + offset)
self:SetRenderAngles(hand.Ang)

self:SetBodygroup(1,1)

self:DrawModel()

if (CLIENT) then
self:SetModelScale(Vector(1.15,1.15,1.15))
end
end

SWEP.Instructions 			= ""
SWEP.Author   				= "Zoey"
SWEP.Contact        		= ""

SWEP.Weight = 0

SWEP.ViewModelFlip		= false

SWEP.Spawnable 			= false
SWEP.AdminSpawnable 	= false

SWEP.ViewModel			= "models/zoey/syrette5.mdl"
SWEP.WorldModel			= "models/bloocobalt/l4d/items/w_eq_adrenaline.mdl"

SWEP.Primary.Recoil 		= 0
SWEP.Primary.Damage 		= 0
SWEP.Primary.NumShots 		= 0
SWEP.Primary.Cone 			= 0
SWEP.Primary.ClipSize 		= -1
SWEP.Primary.Delay 			= 0
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Automatic 		= false
SWEP.Primary.Ammo 			= "none"

SWEP.Secondary.Ammo 			= "none"

function SWEP:Initialize()
self:SetWeaponHoldType(self.HoldType)
end


function SWEP:Deploy()
self:SendWeaponAnim(ACT_VM_DRAW)
self.GotoLastWep = nil
self.Heal = nil
self.Inject = CurTime()
self:EmitSound("syr/syr_usefinal.wav")
return true
end

function SWEP:Holster()
return true
end

function SWEP:Reload()
end

/*---------------------------------------------------------
Think
---------------------------------------------------------*/
function SWEP:Think()
self.Owner:ConCommand("-speed")
if self.GotoLastWep and CurTime() >= self.GotoLastWep then
self.GotoLastWep = nil
if SERVER then
if self.Owner.Syrettes <= 0 then
self.Owner:ConCommand("lastinv")
self.Owner:StripWeapon("fc2_syrette")
else
self.Owner:ConCommand("lastinv")
end
end
end
if self.Inject and CurTime() >= self.Inject then
self.Inject = nil
self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
self.GotoLastWep = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Heal = CurTime() + 1.2
end
if self.Heal and CurTime() >= self.Heal then
self.Heal = nil
if SERVER then
if self.Owner:Health() >= self.Owner:GetMaxHealth() then return end
self.Owner.Syrettes = self.Owner.Syrettes - 1
umsg.Start("FCUsedSyrette",self.Owner)
umsg.End()
self.Owner.HealthHardType = 1
self.Owner:SetHealth(self.Owner:GetMaxHealth())
end
end
end

/*---------------------------------------------------------
PrimaryAttack
---------------------------------------------------------*/
function SWEP:PrimaryAttack()
end

/*---------------------------------------------------------
SecondaryAttack
---------------------------------------------------------*/
function SWEP:SecondaryAttack()
end