ENT.Type = "anim"
ENT.PrintName		= "Single Syrette"
ENT.Category		= "FC2"
ENT.Author			= "Zoey"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.AdminSpawnable = true