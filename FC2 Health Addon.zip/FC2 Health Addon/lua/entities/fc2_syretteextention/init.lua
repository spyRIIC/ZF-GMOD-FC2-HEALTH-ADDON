AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include('shared.lua')

ENT.Size = 0

function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal*10

	self.Spawn_angles = ply:GetAngles()
	self.Spawn_angles.pitch = 0
	self.Spawn_angles.roll = 0
	self.Spawn_angles.yaw = self.Spawn_angles.yaw
	
	local ent = ents.Create( "fc2_syretteextention" )
                
	ent:SetPos( SpawnPos )
	ent:SetAngles( self.Spawn_angles )
	ent:Spawn()
	ent:Activate()

	return ent	
end

function ENT:Initialize()

	self:SetModel("models/bloocobalt/l4d/items/w_eq_fieldkit.mdl")
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:DrawShadow( false )
	self:SetUseType(SIMPLE_USE)
	
	self:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self:SetNetworkedString("Owner", "World")
	
	self:GetPhysicsObject():Wake()
end

function ENT:Use(ply)
if ply.HasExtendedKit then return false end
ply.MaxSyrettes = 8
ply.HasExtendedKit = true
ply:EmitSound("items/gunpickup2.wav")
ply.Syrettes = 8
ply:Give("fc2_syrette")
umsg.Start("FCGiveSyrettes",ply)
umsg.Float(ply.Syrettes)
umsg.End()
self:Remove()
end