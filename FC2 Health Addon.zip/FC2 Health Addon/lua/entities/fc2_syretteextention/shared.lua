ENT.Type = "anim"
ENT.PrintName		= "Syrette Upgrade"
ENT.Category		= "FC2"
ENT.Author			= "Zoey"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.AdminSpawnable = true