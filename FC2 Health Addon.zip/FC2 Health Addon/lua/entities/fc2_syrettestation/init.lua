AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include('shared.lua')

ENT.Size = 0

function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal*65

	self.Spawn_angles = ply:GetAngles()
	self.Spawn_angles.pitch = 0
	self.Spawn_angles.roll = 0
	self.Spawn_angles.yaw = self.Spawn_angles.yaw+90
	
	local ent = ents.Create( "fc2_syrettestation" )
                
	ent:SetPos( SpawnPos )
	ent:SetAngles( self.Spawn_angles )
	ent:Spawn()
	ent:Activate()

	return ent	
end

function ENT:Initialize()

	self:SetModel("models/generic/firstaid_ievel.mdl")
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:DrawShadow( true )
	self.TimerStock = 30
	self:SetUseType(SIMPLE_USE)
	
	self:SetCollisionGroup( COLLISION_GROUP_INTERACTIVE )
	self:SetNetworkedString("Owner", "World")
end

function ENT:Think()
if self.TimerStockPlus and CurTime() >= self.TimerStockPlus and self.TimerStock < 30 then
self.TimerStockPlus = CurTime() + 1
self.TimerStock = self.TimerStock + 1
end
end

function ENT:Use(ply)
if ply:IsPlayer() and self.TimerStock < 30 then
ply:ChatPrint("Time left until this station is restocked: "..(30 - self.TimerStock).." Seconds")
return false end
if ply.HasExtendedKit then
ply.MaxSyrettes = 8
else
ply.MaxSyrettes = 6
end
if ply:IsPlayer() and ply.Syrettes < ply.MaxSyrettes then
self.TimerStock = 0
self.TimerStockPlus = CurTime()
ply:EmitSound("items/gunpickup2.wav")
ply.Syrettes = ply.MaxSyrettes
ply:Give("fc2_syrette")
umsg.Start("FCGiveSyrettes",ply)
umsg.Float(ply.Syrettes)
umsg.End()
end
end