ENT.Type = "anim"
ENT.PrintName		= "Syrette Stock"
ENT.Category		= "FC2"
ENT.Author			= "Zoey"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.AdminSpawnable = true